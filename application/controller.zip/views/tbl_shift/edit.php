<div class="">

                    <div class="clearfix"></div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12 ">
                            <div class="x_panel" style="width:101% !important;">
                                <div class="x_title">

                                    <div class="title_right">

                                        <div class="col-md-5 col-sm-5  form-group pull-right top_search" style="margin-top:10px;">
                                            <h5><u>Edit Shift</u></h5>
                                        </div>

                                    </div>

                                    <ul class="nav navbar-right panel_toolbox">
                                        <li>
                                            <a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>


                                    </ul>
                                    <div class="nav navbar-right panel_toolbox  form-group pull-right top_search">
                                        <div class="input-group" style="width:98%;">
                                            <input type="text" class="form-control" placeholder="Search for...">
                                            <span class="input-group-btn">
                                                <button class="btn btn-default" type="button">Go!</button>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>

<?php //print_r($tbl_shift) ?>

                                <div class="x_content">
								<?php if($error){ ?>
									<div class="alert alert-danger alert-dismissible " role="alert">
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
</button>
<strong><?=$error?></strong>
</div>
								<?php }?>
								<?php echo form_open('tbl_shift/edit/'.$tbl_shift['id'],array("class"=>"form-horizontal")); ?>
                                    <div class="row">



                                        <div class="col-md-3 col-sm-12  form-group">
                                            <label>
                                               Shift Name<span class="required">*</span>
                                            </label>
                                            <input name="shift_name" type="text" value="<?php echo ($this->input->post('shift_name') ? $this->input->post('shift_name') : $tbl_shift['shift_name']); ?>" class="form-control" required>
                                        </div>
                                        <div class="col-md-3 col-sm-12  form-group">
                                            <label>
                                                Open Date <span class="required">*</span>
                                            </label>
                                            <input id="birthday" name="open_date" value="<?php echo ($this->input->post('open_date') ? $this->input->post('open_date') : date('d-m-Y',strtotime($tbl_shift['open_date']))); ?>" class="form-control"  type="text" required="required" >
                                            <script>
                                                function timeFunctionLong(input) {
                                                    setTimeout(function () {
                                                        input.type = 'text';
                                                    }, 60000);
                                                }
                                            </script>
                                        </div>

                                        <!--<div class="col-md-3 col-sm-12  form-group">
                                            <label>
                                                Next Day <span class="required">*</span>
                                            </label>
                                            <input name="next_day" type="text" value="<?php echo ($this->input->post('next_day') ? $this->input->post('next_day') : $tbl_shift['next_day']); ?>" class="form-control" required>
                                        </div>-->
                                        <div class="col-md-3 col-sm-12  form-group">
                                            <label>
                                                Shift Working For <span class="required">*</span>
                                            </label>


                                            <select name="shift_working_for" class="select2_single form-control" tabindex="-1">
                                                <option value="Web Panel">Web Panel </option>
                                            </select>
                                        </div>
                                       <!-- <div class="col-md-3 col-sm-12  form-group">
                                            <label>
                                                Owner <span class="required">*</span>
                                            </label>
											<div class="input-group date datetimepicker3">
                                            <input name="owner" type="text" value="<?php echo ($this->input->post('owner') ? $this->input->post('owner') : $tbl_shift['owner']); ?>" class="form-control ">
											<span class="input-group-addon">
               <span class="glyphicon glyphicon-time"></span>
               </span>
			   </div>
                                        </div>-->
                                        <div class="col-md-3 col-sm-12  form-group">
                                            <label>
                                                Super Admin <span class="required">*</span>
                                            </label>
                                         <div class="input-group date datetimepicker3">
                                            <input name="super_admin" type="text" value="<?php echo ($this->input->post('super_admin') ? $this->input->post('super_admin') : $tbl_shift['super_admin']); ?>" class="form-control ">
											<span class="input-group-addon">
               <span class="glyphicon glyphicon-time"></span>
               </span>
			   </div>
                                        </div>
										<!--
                                        <div class="col-md-3 col-sm-12  form-group">
                                            <label>
                                                Fanter <span class="required">*</span>
                                            </label>
                                            <div class="input-group date datetimepicker3">
                                            <input name="fanter" type="text" value="<?php echo ($this->input->post('fanter') ? $this->input->post('fanter') : $tbl_shift['fanter']); ?>" class="form-control ">
											<span class="input-group-addon">
               <span class="glyphicon glyphicon-time"></span>
               </span>
			   </div>
                                        </div>
                                        <div class="col-md-3 col-sm-12  form-group">
                                            <label>
                                                Cash Agent <span class="required">*</span>
                                            </label>
                                            <div class="input-group date datetimepicker3">
                                            <input name="cash_agent" value="<?php echo ($this->input->post('cash_agent') ? $this->input->post('cash_agent') : $tbl_shift['cash_agent']); ?>" type="text" class="form-control ">
											<span class="input-group-addon">
               <span class="glyphicon glyphicon-time"></span>
               </span>
			   </div>
                                        </div>
                                        <div class="col-md-3 col-sm-12  form-group">
                                            <label>
                                                Admin <span class="required">*</span>
                                            </label>
                                           <div class="input-group date datetimepicker3">
                                            <input name="admin" type="text" value="<?php echo ($this->input->post('admin') ? $this->input->post('admin') : $tbl_shift['admin']); ?>" class="form-control ">
											<span class="input-group-addon">
               <span class="glyphicon glyphicon-time"></span>
               </span>
			   </div>
                                        </div>-->
                                        <div class="col-md-3 col-sm-12  form-group">
                                            <label>
                                                Data Entry Operator<span class="required">*</span>
                                            </label>
                                            <div class="input-group date datetimepicker3">
                                            <input name="data_entry_operator" type="text" value="<?php echo ($this->input->post('data_entry_operator') ? $this->input->post('data_entry_operator') : $tbl_shift['data_entry_operator']); ?>" class="form-control ">
											<span class="input-group-addon">
               <span class="glyphicon glyphicon-time"></span>
               </span>
			   </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 offset-md-3" style="margin-top:39px;">
                                        
                                        <button type="submit" class="btn btn-success" style="padding: .375rem 2.75rem;">Submit</button>
                                    </div>
                                <?php echo form_close(); ?>
								</div>
                            </div>
                        </div>
                    </div>


                    

                </div>
				<script src="<?php echo base_url(); ?>/assets/js/jquery.min.js"></script>
				 <!-- jQuery -->
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>/assets/js/bootstrap.bundle.min.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	
    
    <!-- bootstrap-daterangepicker -->
    <script src="<?php echo base_url(); ?>/assets/js/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/bootstrap-datetimepicker.min.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>/assets/js/custom.min.js"></script>
				<script>
				 jQuery(function() {
   $('#birthday').datepicker().datepicker("option", "dateFormat", 'dd-mm-yy');
 $('#birthday').datepicker('setDate', '<?php echo date("d-m-Y",strtotime($tbl_shift["open_date"])); ?>');
 
});
				</script>

